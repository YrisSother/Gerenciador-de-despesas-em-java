import java.util.Scanner;
public class Usuario {

    Scanner sc = new Scanner(System.in);
    Conta count = new Conta();
   
    public void nome() {

        System.out.println("Bem vindo(a) insira o seu  nome: ");
        sc.nextLine();


    }
    
}
